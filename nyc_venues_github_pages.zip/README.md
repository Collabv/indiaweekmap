
# NYC Venues Map (GitHub Pages)

Interactive Folium map showing NYC venues with distances from Lincoln Center.

## Publish on GitHub Pages
1. Create a **new GitHub repo** (public is easiest).
2. Upload `index.html` and `README.md` from this zip.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose:
   - **Source**: Deploy from a branch
   - **Branch**: `main` (or `master`) and `/ (root)`
5. Save. Your site will be live at:
   `https://<your-username>.github.io/<repo-name>/`
